import React from 'react';

const Dashboard = () => {
    return (
        <div>
            Dash
        </div>
    );
};

export default Dashboard;